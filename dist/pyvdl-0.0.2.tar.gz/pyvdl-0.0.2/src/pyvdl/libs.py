try:
    import matplotlib.pyplot as plt
    import numpy as np
    import cv2
except:
    print("install libs use: (python3 -m pip install matplotlib numpy opencv-python)")